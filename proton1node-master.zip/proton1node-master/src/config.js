const database = {
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'inventario',
}

module.exports = { 
    database
}